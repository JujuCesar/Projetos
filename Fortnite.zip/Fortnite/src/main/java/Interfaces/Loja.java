package Interfaces;

public interface Loja {

    default void gastarVbucks() {

    }

    default void comprarVbucks() {

    }

}
