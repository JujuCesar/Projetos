package Interfaces;

import Pessoas.Jogador;

public interface Interacao {

    default void passarMissao() {

    }

}
