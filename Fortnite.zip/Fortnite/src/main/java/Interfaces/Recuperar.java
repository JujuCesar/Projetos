package Interfaces;

import Pessoas.Jogador;

public interface Recuperar {

    default void recuperarVida(){

    }

    default void recuperarEscudo(){

    }

}
