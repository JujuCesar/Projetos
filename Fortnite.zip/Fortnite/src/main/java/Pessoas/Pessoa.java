package Pessoas;

public abstract class Pessoa {

    public static int qntdPessoa = 0;
    private String nome;

    public Pessoa(int qntdPessoa, String nome) {
        this.qntdPessoa = qntdPessoa;
        this.nome = nome;
    }

    // Getter e Setter

    public static int getQntdPessoa() {
        return qntdPessoa;
    }

    public String getNome() {
        return nome;
    }


    // Métodos

    public void mostraInfo(){

    }

    abstract void fazMissao();

}
