package Pessoas;

public class Mochila {

    private String raridade;

    public Mochila(String raridade) {
        this.raridade = raridade;
    }
}
