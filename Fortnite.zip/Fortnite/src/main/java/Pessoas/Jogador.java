package Pessoas;

import Interfaces.Loja;
import Interfaces.Recuperar;

public class Jogador extends Pessoa implements Recuperar, Loja {

    // Atributos da classe
    private int nivel = 0;

    private boolean passeBatalha;

    private int vida=0;

    private int escudo=0;

    // Agregando Skin e Mochila
    Skin skin;
    Mochila mochila;

    // Construtor herdado
    public Jogador(int qntdPessoa, String nome, int nivel, boolean passeBatalha, Skin skin, Mochila mochila) {
        super(qntdPessoa, nome);
        this.nivel = nivel;
        this.passeBatalha = passeBatalha;
        this.vida = vida;
        this.escudo = escudo;
        this.skin = skin;
        this.mochila = mochila;
    }

    // Getter e setter
    public int getNivel() {
        return nivel;
    }

    public boolean isPasseBatalha() {
        return passeBatalha;
    }

    public int getVida() {
        return vida;
    }

    public int getEscudo() {
        return escudo;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public void setEscudo(int escudo) {
        this.escudo = escudo;
    }


    // Métodos

    @Override
    public void mostraInfo(){
        System.out.println("Skin: " +skin.getNome());
        System.out.println("Raridade: " +skin.getRaridade());
    }

    @Override
    public void fazMissao(){
        System.out.println(getNome() +" completou uma missão!");
        setNivel(+1);
    }

    @Override
    public void recuperarVida(){
        setVida(+15);
        if (getVida() > 100)
            setVida(100);
    }

    @Override
    public void recuperarEscudo(){
        setEscudo(+25);
        if (getEscudo() > 100)
            setEscudo(100);
    }

    @Override
    public void gastarVbucks() {
        System.out.println("Gastou V Bucks na loja!");
    }

    @Override
    public void comprarVbucks() {
        System.out.println("Comprou V Bucks na loja");
    }

}
