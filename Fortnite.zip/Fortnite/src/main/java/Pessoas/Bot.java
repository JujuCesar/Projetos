package Pessoas;

import Interfaces.Interacao;

public class Bot extends Pessoa implements Interacao {

    private boolean hostil; // boolean pra ver se é hostil ou não


    // Construtor herdado + hostilidade
    public Bot(int qntdPessoa, String nome, boolean hostil) {
        super(qntdPessoa, nome);
        this.hostil = hostil;
    }

    // Getter

    public boolean isHostil() {
        return hostil;
    }


    // Métodos legais

    @Override
    public void mostraInfo(){
        System.out.println("Não possui Skin.");
        System.out.println("Não possui mochila.");

    }

    @Override
    public void fazMissao(){
        if (hostil ==false) {
            System.out.println("Ajudou o jogador a fazer a missão");
        }

        else
            System.out.println("Atrapalhou o jogador a fazer a missão");

    }

    @Override
    public void passarMissao() {
        if (hostil == false) {
            System.out.println("Este Bot passa missões!");
        }

        else
            System.out.println("Este Bot não passa missões!");
    }



}
