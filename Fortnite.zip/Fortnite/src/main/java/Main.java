import Pessoas.*;

public class Main {

    public static void main(String[] args) {

        int aux = 0; // Variavel para contagem de objetos criados de classe abstract

        Pessoa pessoas[] = new Pessoa[10]; // Array para pessoas

        Skin s1 = new Skin("Padrão", "Comum"); // Criando skin
        Mochila m1 = new Mochila("Comum"); // Criando mochila

        Bot b1 = new Bot(1,"vi", false); // Criando bot
        Jogador j1 = new Jogador(1,"Julio", 0, false ,s1, m1 ); // Criando jogador

        // Jogando eles na array
        pessoas [0] = b1;
        pessoas [1] = j1;

        // Varrendo array e executando métodos
        for (int i = 0; i < pessoas.length ; i++) {
            if (pessoas[i] != null){
                aux++;
                if(pessoas[i] instanceof Bot) {
                    b1 = (Bot) pessoas[i];
                    b1.passarMissao();
                    b1.fazMissao();
                    b1.mostraInfo();
                }

                else{
                    j1 = (Jogador) pessoas[i];
                    j1.mostraInfo();
                    j1.recuperarVida();
                    j1.recuperarEscudo();
                    j1.fazMissao();
                    j1.comprarVbucks();
                    j1.gastarVbucks();
                }

            }
        }

        System.out.println("Numero de pessoas criadas através do atributo estático: " +aux);


    }

}
