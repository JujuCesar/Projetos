import Redes.*;
import Redes.Usuario;

import java.util.Scanner;



public class Main {

    public static void main(String[] args) {

        String nom, em;

        boolean flag = true;//VARIAVEL PARA CONTROLE DO MENU PRINCIPAL
        boolean flagFacebook = true; // Variavel para controle do menu do facebook
        boolean flagGooglePlus = true; // Variavel para controle do menu do googlePlus
        boolean flagTwitter = true; // Variavel para controle do menu do twitter
        boolean flagInstagram = true; // Variavel para controle do menu do instagram


        Scanner in = new Scanner(System.in);//PARA LEITURA DE DADOS

        System.out.println("Nome: ");
        String nomeUsuario = in.nextLine();
        System.out.println("E-mail: ");
        String emailUsuario = in.nextLine();
        System.out.println("Senha: ");
        String senha = in.nextLine();

        Usuario usuario = new Usuario(nomeUsuario, emailUsuario);

        while (flag) {

            System.out.println(" ");
            System.out.println("Qual Rede Social deseja acessar?");
            System.out.println("1-Facebook");
            System.out.println("2-GooglePlus");
            System.out.println("3-Twitter");
            System.out.println("4-Instagram");
            System.out.println("5-Fechar navegador web ");

            int op; // Variavel auxiliar para o menu
            op = in.nextInt();

            switch (op) {


                case 1:
                    // Facebook
                    System.out.println(" ");
                    System.out.println("Bem vindo ao facebook!");
                    int amigosFace = 160;

                    Facebook facebook = new Facebook(senha, amigosFace);

                    while (flagFacebook){// flag do menu do facebook

                    System.out.println(" ");
                    System.out.println("Bem vindo ao facebook " +nomeUsuario +"!");
                    System.out.println("1-Postar foto");
                    System.out.println("2-Postar video ");
                    System.out.println("3-postar Comentário ");
                    System.out.println("4-Curtir publicação");
                    System.out.println("5-Fazer uma transmissão ao vivo ");
                    System.out.println("6-Compartilhar ");
                    System.out.println("7-Sair da sua conta ");
                    System.out.println(" ");


                    int facebookop; // Variavel auxiliar para o menu do facebook
                    facebookop = in.nextInt();


                         switch (facebookop) {

                            case 1:
                                facebook.PostarFoto();
                                break;

                            case 2:
                                facebook.PostarVideo();
                                break;

                            case 3:
                                facebook.PostarComentario();
                                break;

                            case 4:
                                facebook.CurtirPublicacao();
                                break;

                            case 5:
                                facebook.fazStreaming();
                                break;

                            case 6:
                                facebook.compartilhar();
                                break;

                            case 7:
                                // Sair da conta e voltar para o menu de sites
                                flagFacebook = false;
                                System.out.println("Você saiu do facebook.");
                                break;
                        }
                    }
                    break;


                case 2:
                    // GooglePlus
                    System.out.println(" ");
                    System.out.println("Bem vindo ao GooglePlus!");
                    int amigosGoogle = 230;

                    GooglePlus googlePlus = new GooglePlus(senha,amigosGoogle);

                    while (flagGooglePlus) {

                        System.out.println(" ");
                        System.out.println("Bem vindo ao googlePlus " + nomeUsuario + "!");
                        System.out.println("1-Postar foto");
                        System.out.println("2-Postar video ");
                        System.out.println("3-postar Comentário ");
                        System.out.println("4-Curtir publicação");
                        System.out.println("5-Fazer uma transmissão ao vivo ");
                        System.out.println("6-Compartilhar ");
                        System.out.println("7-Sair da sua conta ");
                        System.out.println(" ");

                        int GooglePlusop; // Variavel auxiliar para o menu do googlePlus
                        GooglePlusop = in.nextInt();


                        switch (GooglePlusop) {

                            case 1:
                                googlePlus.PostarFoto();
                                break;

                            case 2:
                                googlePlus.PostarVideo();
                                break;

                            case 3:
                                googlePlus.PostarComentario();
                                break;

                            case 4:
                                googlePlus.CurtirPublicacao();
                                break;

                            case 5:
                                googlePlus.fazStreaming();
                                break;

                            case 6:
                                googlePlus.compartilhar();
                                break;

                            case 7:
                                // Sair do googlePlus
                                flagGooglePlus = false;
                                System.out.println("Você saiu do googlePlus.");
                                break;
                        }
                    }
                    break;


                case 3:
                    // Twitter
                    System.out.println(" ");
                    System.out.println("Bem vindo ao Twitter!");
                    int amigosTwitter = 730;

                    Twitter twitter = new Twitter(senha,amigosTwitter);

                    while (flagTwitter){

                    System.out.println(" ");
                    System.out.println("Bem vindo ao Twitter " +nomeUsuario +"!");
                    System.out.println("1-Postar foto");
                    System.out.println("2-Postar video ");
                    System.out.println("3-postar Comentário ");
                    System.out.println("4-Curtir publicação");
                    System.out.println("5-Compartilhar ");
                    System.out.println("6-Sair da sua conta ");
                    System.out.println(" ");


                    int Twitterop; // variavel para auxiliar no menu do twitter
                    Twitterop = in.nextInt();


                        switch (Twitterop){

                            case 1:
                                twitter.PostarFoto();
                                break;

                            case 2:
                                twitter.PostarVideo();
                                break;

                            case 3:
                                twitter.PostarComentario();
                                break;

                            case 4:
                                twitter.CurtirPublicacao();
                                break;

                            case 5:
                                twitter.compartilhar();
                                break;

                            case 6:
                                // Sair do Twitter
                                flagTwitter = false;
                                System.out.println("Você saiu do Twitter.");
                                break;
                        }
                    }
                    break;


                case 4:
                    // Instagram
                    System.out.println(" ");
                    System.out.println("Bem vindo ao Instagram!");
                    int amigosInstagram = 730;

                    Instagram instagram = new Instagram(senha, amigosInstagram);

                    while(flagInstagram){

                    System.out.println(" ");
                    System.out.println("Bem vindo ao Instagram " +nomeUsuario +"!");
                    System.out.println("1-Postar foto");
                    System.out.println("2-Postar video ");
                    System.out.println("3-postar Comentário ");
                    System.out.println("4-Curtir publicação");
                    System.out.println("5-Compartilhar ");
                    System.out.println("6-Sair da sua conta ");
                    System.out.println(" ");

                    int Instaop; // Variavel para o menu do instagram
                    Instaop = in.nextInt();


                        switch (Instaop){

                            case 1:
                                instagram.PostarFoto();
                                break;

                            case 2:
                                instagram.PostarVideo();
                                break;

                            case 3:
                                instagram.PostarComentario();
                                break;

                            case 4:
                                instagram.CurtirPublicacao();
                                break;

                            case 5:
                                instagram.compartilhar();
                                break;

                            case 6:
                                // Sair do Instagram
                                flagInstagram = false;
                                System.out.println("Você saiur do Instagram. ");
                                break;
                        }
                    }
                    break;


                case 5:
                    // Fechar navegador web
                    flag = false;
                    System.out.println("Você fechou o navegador web. ");
                    break;
            }

        }




    }

}
