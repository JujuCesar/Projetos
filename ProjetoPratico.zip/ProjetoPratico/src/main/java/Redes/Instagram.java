package Redes;

import Interfaces.Compartilhamento;

public class Instagram extends RedeSocial implements Compartilhamento {
    public Instagram(String senha, int amigos) {
        super(senha, amigos);
    }


    // Métodos herdades de Rede Social
    @Override
    public void PostarFoto() {
        System.out.println("Você postou uma foto no Instagram! ");
    }

    @Override
    public void PostarVideo() {
        System.out.println("Você postou um vídeo no Instagram! ");
    }

    @Override
    public void PostarComentario() {
        System.out.println("Você postou um comentário em uma publicação no Instagram! ");
    }

    @Override
    public void CurtirPublicacao() {
        System.out.println("Você curtiu uma publicação no Instagram! ");
    }

    // Métodos da interface

    @Override
    public void compartilhar() {
        System.out.println("Você compartilhou uma publicação no Instagram! ");
    }

}
