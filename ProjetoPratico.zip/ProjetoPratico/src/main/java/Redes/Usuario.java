package Redes;

public class Usuario {

    private String nome;

    private String email;

    public Usuario(String nome, String email) {
        this.nome = nome;
        this.email = email;
    }

    // Getter para o nome e email
    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    // Métodos
    void Usuario(RedeSocial[] redeSocials){

    }

}