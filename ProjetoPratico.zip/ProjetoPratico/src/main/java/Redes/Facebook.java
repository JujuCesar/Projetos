package Redes;

import Interfaces.Compartilhamento;
import Interfaces.VideoConferencia;

public class Facebook extends RedeSocial implements VideoConferencia, Compartilhamento {

    // Construtor herdado
    public Facebook(String senha, int amigos) {
        super(senha, amigos);
    }

    // Métodos herdados de Rede social
    @Override
    public void PostarFoto() {
        System.out.println("Você postou uma foto no facebook! ");
    }

    @Override
    public void PostarVideo() {
        System.out.println("Você postou um vídeo no facebook! ");
    }

    @Override
    public void PostarComentario() {
        System.out.println("Você postou um comentário em uma publicação no facebook! ");
    }

    @Override
    public void CurtirPublicacao() {
        System.out.println("Você curtiu uma publicação no facebook! ");
    }

    // Métodos das interfaces

    @Override
    public void fazStreaming(){
        System.out.println("Você está ao vivo no Facebook! ");
    }

    @Override
    public void compartilhar(){
        System.out.println("Você compartilhou uma publicação no Facebook! ");
    }

}
