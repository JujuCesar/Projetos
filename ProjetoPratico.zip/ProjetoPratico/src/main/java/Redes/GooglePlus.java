package Redes;

import Interfaces.Compartilhamento;
import Interfaces.VideoConferencia;

public class GooglePlus extends RedeSocial implements VideoConferencia, Compartilhamento {


    public GooglePlus(String senha, int amigos) {
        super(senha, amigos);
    }


    // Métodos herdados de Rede Social
    @Override
    public void PostarFoto() {
        System.out.println("Você postou uma foto no googlePlus! ");
    }

    @Override
    public void PostarVideo() {
        System.out.println("Você postou um vídeo no googlePlus! ");
    }

    @Override
    public void PostarComentario() {
        System.out.println("Você postou um comentário em uma publicação no googlePlus! ");
    }

    @Override
    public void CurtirPublicacao() {
        System.out.println("Você curtiu uma publicação no googlePlus! ");
    }


    // Métodos das interfaces

    @Override
    public void fazStreaming(){
        System.out.println("Você está ao vivo no googlePlus! ");
    }

    @Override
    public void compartilhar(){
        System.out.println("Você compartilhou uma publicação no googlePlus! ");
    }

}
