package Redes;

public abstract class RedeSocial {

    // Atributos
    protected String senha;

    protected int Amigos;

    public RedeSocial(String senha, int amigos) {
        this.senha = senha;
        this.Amigos = amigos;
    }

    // Métodos

    public abstract void PostarFoto();

    public abstract void PostarVideo();

    public abstract void PostarComentario();

    public abstract void CurtirPublicacao();

    public abstract void compartilhar();
}
