package Redes;

import Interfaces.Compartilhamento;

public class Twitter extends RedeSocial implements Compartilhamento {
    public Twitter(String senha, int amigos) {
        super(senha, amigos);
    }

    // Métodos herdade de Rede Social
    @Override
    public void PostarFoto() {
        System.out.println("Você postou uma foto no Twitter! ");
    }

    @Override
    public void PostarVideo() {
        System.out.println("Você postou um vídeo no Twitter! ");
    }

    @Override
    public void PostarComentario() {
        System.out.println("Você postou um comentário em uma publicação no Twitter! ");
    }

    @Override
    public void CurtirPublicacao() {
        System.out.println("Você curtiu uma publicação no Twitter! ");
    }


    // Métodos da interface

    @Override
    public void compartilhar(){
        System.out.println("Você compartilhou uma publicação no Twitter! ");
    }

}
