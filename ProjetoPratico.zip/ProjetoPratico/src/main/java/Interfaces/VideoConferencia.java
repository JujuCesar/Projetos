package Interfaces;

public interface VideoConferencia {

    default void fazStreaming(){

    }

}
