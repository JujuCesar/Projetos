package Interfaces;

public interface Compartilhamento {

    default void compartilhar(){

    }

}
