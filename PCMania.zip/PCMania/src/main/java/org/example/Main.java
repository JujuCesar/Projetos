import java.util.Scanner;

public class Main {
    public static void main(String[] args){

        Computador[] computadores = new Computador[100]; // Array de computadores

        // Agregações
        SistemaOperacional sistemaOperacional;

        MemoriaUSB memoriaUSB;

        HardwareBasico hardwareBasico1 = new HardwareBasico("Pentium Core i3 (2200 Mhz), 8 Gb de Memória RAM", 500);

        HardwareBasico hardwareBasico2 = new HardwareBasico("Pentium Core i5 (3370 Mhz), 16 Gb de Memória RAM", 1000);

        HardwareBasico hardwareBasico3 = new HardwareBasico("Pentium Core i7 (4500 Mhz), 32 Gb de Memória RAM", 2000);

        //Declarando computadores
        Computador promocao1 = new Computador("Positivo", 2300);

        Computador promocao2 = new Computador("Acer", 5800);

        Computador promocao3 = new Computador("Vaio", 1800);

        // Menu
        boolean flag = true;//VARIAVEL PARA CONTROLE DO MENU

        Scanner in = new Scanner(System.in);//PARA LEITURA DE DADOS

        System.out.println("Por favor, insira seu nome:");
        String nomeUsuario = in.nextLine();
        System.out.println("Por favor, insira seu cpf:");
        long cpfUsuario = in.nextLong();
        Cliente cliente = new Cliente(nomeUsuario, cpfUsuario);

        while (flag){

            System.out.println(" ");
            System.out.println("Bem vindo ao menu da loja");



            System.out.println("1- Ver promoções");
            System.out.println("2-Adicionar PC no carrinho");
            System.out.println("3-Mostrar configurações do PC");
            System.out.println("4-Calcular total da compra");
            System.out.println("5-Sair do menu");

            int op; // Variavel auxiliar para o menu
            op = in.nextInt();

            switch (op){

            case 1:
                // Ver promoções
                System.out.println(" ");
                System.out.println("Promoção 1:");
                System.out.println("Marca: Positivo");
                System.out.println("Preço: R$2300,00");
                System.out.println(" ");
                System.out.println("Promoção 2:");
                System.out.println("Marca: Acer");
                System.out.println("Preço: R$5800,00");
                System.out.println(" ");
                System.out.println("Promoção 3:");
                System.out.println("Marca: Vaio");
                System.out.println("Preço: R$1800,00");

                break;

            case 2:
                // Adicionar pc no carrinho
                System.out.println("Entre com o número da promoção que deseja:");

                int ip; // variavel para auxiliar na leitura das promo
                ip = in.nextInt();

                switch (ip){
                    case 1:
                    cliente.total += promocao1.preco;

                    System.out.println("Pc Positivo adicionado ao carrinho!");
                    break;

                    case 2:
                    cliente.total += promocao2.preco;
                    System.out.println("Pc Acer adicionado ao carrinho!");
                    break;

                    case 3:
                    cliente.total += promocao3.preco;
                    System.out.println("Pc Vaio adicionado ao carrinho!");
                    break;

                }



                break;

            case 3:
                // Mostrar configuração do PC
                System.out.println("Entre com o numero da promoção que deseja consultar:");
                int ap; // variavel para auxiliar a entrada para consultar config
                ap = in.nextInt();

                switch (ap){
                    case 1:

                        break;

                    case 2:

                        break;

                    case 3:

                        break;
                }

                break;

            case 4:
                //Calcular total da compra
                System.out.println("Total: R$" +cliente.total +"0");
                break;

            case 5:
                // Sair do menu
                flag = false;
                System.out.println("Volte sempre!");
                break;


            }
        }


    }
}