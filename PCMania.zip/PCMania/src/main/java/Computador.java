public class Computador {

    String marca;
    float preco;

    Computador[] computadores = new Computador[100];

    public Computador(String marca, float preco) {
        this.marca = marca;
        this.preco = preco;
    }

    // Agregações

    MemoriaUSB memoriaUSB;

    SistemaOperacional sistemaOperacional;

    HardwareBasico hardwareBasicos[] = new HardwareBasico[100];

    Cliente cliente;



    // Métodos

    void mostraPCConfigs(){
        System.out.println("Configurações:");

    }

    void addMemoriaUSB(){

    }

}