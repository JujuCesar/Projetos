public class SistemaOperacional {

    String nome;
    int tipo;

    public SistemaOperacional(String nome, int tipo) {
        this.nome = nome;
        this.tipo = tipo;
    }
}
