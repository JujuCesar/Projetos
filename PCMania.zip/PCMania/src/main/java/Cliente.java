public class Cliente {

    String nome;
    long cpf;


    public Cliente(String nome, long cpf) {
        this.nome = nome;
        this.cpf = cpf;
    }


    // Métodos
    float total = 0;
    float calculaTotalCompra(){
        System.out.println("Total:");
            return total;

    }


}
