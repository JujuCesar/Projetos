import Astronautas.Impostor;
import Astronautas.Pet;
import Astronautas.Skin;
import Astronautas.Tripulante;

public class Main {

    public static void main(String[] args) {

        Skin s1 = new Skin("Comum");
        Pet p1 = new Pet("nenhum");
        Tripulante trip1 = new Tripulante(1,"Amarelo", "Vitor", s1, p1 );
        Impostor imp1 = new Impostor(2,"Vermelho", "Julio", s1, p1);

        trip1.mostraInfo();
        imp1.mostraInfo();

        trip1.verCameras();

        trip1.reparar();
        trip1.reportar();

        trip1.fazerMissao();

        trip1.mostraInfo();

        imp1.fazerMissao();

        imp1.usarVentoinha();

        imp1.trancarPortas("Cafeteria");

        imp1.executar();

        imp1.mostraInfo();




    }

}
