package Astronautas;

import Interfaces.Missao;

public class Tripulante extends Astronauta implements Missao {

    private int qtdMissoes = 7; //Variavel para missoes feitas
    public Tripulante(int cont, String cor, String nome, Skin skin, Pet pet) {
        super(cont, cor, nome, skin, pet);
    }

    // Getter e Setter

    public void setQtdMissoes(int qtdMissoes) {

        this.qtdMissoes = qtdMissoes;
    }

    // Métodos herdados
    @Override
    public void mostraInfo() {
        super.mostraInfo();
        System.out.println("Missões restantes: " +qtdMissoes);
    }


    // Sobreescrevendo métodos Reparar e Reportar
    @Override
    public void reportar() {
        System.out.println(getNome() +" reportou um corpo");
    }

    @Override
    public void reparar() {
        System.out.println(getNome() +" fez um reparo");
    }



    @Override
    public void fazerMissao() {

        System.out.println(getNome() +" fez uma missão" );
        qtdMissoes--;

    }


}
