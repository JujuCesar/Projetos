package Astronautas;

import Interfaces.Executar;
import Interfaces.Missao;
import Interfaces.Sabotar;

public class Impostor extends Astronauta implements Missao, Sabotar, Executar {

    private int qtdMortes; //Variavel para mortes feitas

    // Construtor herdado
    public Impostor(int cont, String cor, String nome, Skin skin, Pet pet) {
        super(cont, cor, nome, skin, pet);
    }


    // Getter e Setter
    public void setQtdMortes(int qtdMortes) {

        this.qtdMortes = qtdMortes;
    }



    // Métodos do impostor
    public void usarVentoinha(){
        System.out.println("O impostor se escondeu na ventoinha");
    }

    public void trancarPortas( String local){
        System.out.println("O impostor trancou as portas do(a) " +local);
    }

    // Métodos herdados
    @Override
    public void mostraInfo() {
        super.mostraInfo();
        System.out.println("Mortes: " +qtdMortes);
    }


    // Sobreescrevendo métodos Reparar e Reportar
    @Override
    public void reportar() {
        System.out.println(getNome() +" fez um self report");
    }

    @Override
    public void reparar() {
        System.out.println(getNome() +" fingiu que fez um reparo");
    }

    // Sobreescrevendo demais métodos
    @Override
    public void fazerMissao() {

        System.out.println(getNome() +" fingiu fazer uma missão");

    }

    @Override
    public void sabotarLuz() {
        System.out.println("O impostor Sabotou a luz");
    }

    @Override
    public void sabotarOxigenio() {
        System.out.println("O impostor sabotou o oxigenio");
    }

    @Override
    public void sabotarReator() {
        System.out.println("O impostor sabotou o reator");
    }

    @Override
    public void sabotarComunicacao() {
        System.out.println("O impostor sabotou a comunicação");
    }

    @Override
    public void executar() {
        System.out.println(getNome() +" matou um tripulante");
        qtdMortes++;
    }

}
