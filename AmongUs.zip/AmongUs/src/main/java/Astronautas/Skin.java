package Astronautas;

public class Skin {

    String tipo; // Tipo da skin

    public Skin(String tipo) {
        this.tipo = tipo;
    }
}
