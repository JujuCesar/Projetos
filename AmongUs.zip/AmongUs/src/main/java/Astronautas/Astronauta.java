package Astronautas;

public abstract class Astronauta {

    int cont; // Contador de jogadores
    private String cor; // Cor do boneco

    private String nome; // nome do jogador

    public Astronauta(int cont, String cor, String nome, Skin skin, Pet pet) {
        this.cont = cont;
        this.cor = cor;
        this.nome = nome;
        this.skin = skin;
        this.pet = pet;
    }
    Skin skin; // Skin do boneco

    Pet pet; // pet do boneco

    // Getter para o nome
    public String getNome() {
        return nome;
    }

    public void mostraInfo() {
        System.out.println("Nome: " +nome);
        System.out.println("Cor: " +cor);
        System.out.println("Skin: " + skin.tipo);
        System.out.println("Pet: " +pet.nome);
    }

    public void verCameras() {

        System.out.println(nome +" olhou as cameras");
    }


    abstract void reportar();

    abstract void reparar();


}
