package Astronautas;

public class Pet {

    String nome; // Tipo do pet

    public Pet(String nome) {
        this.nome = nome;
    }
}
