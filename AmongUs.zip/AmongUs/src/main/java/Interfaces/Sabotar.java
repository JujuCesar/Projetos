package Interfaces;

public interface Sabotar {

    default void sabotarLuz() {
        System.out.println("O impostor Sabotou a luz");
    }

    default void sabotarOxigenio() {
        System.out.println("O impostor sabotou o oxigenio");
    }

    default void sabotarReator() {
        System.out.println("O impostor sabotou o reator");
    }

    default void sabotarComunicacao() {
        System.out.println("O impostor sabotou a comunicação");
    }

}
