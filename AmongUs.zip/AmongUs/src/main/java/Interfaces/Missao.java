package Interfaces;

import Astronautas.Astronauta;
import Astronautas.Tripulante;

public interface Missao {

    default void fazerMissao() {

    }

}
