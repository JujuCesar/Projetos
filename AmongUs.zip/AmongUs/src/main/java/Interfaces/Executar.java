package Interfaces;

public interface Executar {

    default void executar() {

    }

}
