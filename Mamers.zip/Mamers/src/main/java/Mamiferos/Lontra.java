package Mamiferos;

import Interface.Aquatico;

public class Lontra extends Mamifero implements Aquatico{


    public Lontra(String nome, double vida) {
        super(nome, vida);
    }

    @Override
    public void emitirSom() {
        System.out.println("Som de lontra...");
    }

    @Override
    public void nadar(Mamifero mamifero){
        System.out.println(mamifero.getNome() +" está nadando.");
    }

    @Override
    public void mostraInfo() {
        super.mostraInfo();
    }
}
