package Interface;

import Mamiferos.Mamifero;

public interface Aquatico {

    public default void nadar(Mamifero mamifero){
        System.out.println(mamifero.getNome() +" está nadando.");
    }

}
