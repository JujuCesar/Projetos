import Mamiferos.Boi;
import Mamiferos.Cachorro;
import Mamiferos.Lontra;
import Mamiferos.Mamifero;

public class Main {

    public static void main(String[] args) {

        Cachorro c1 = new Cachorro("Dog Mau", 200);
        Lontra l1 = new Lontra("Lontrinha",145);
        Boi b1 = new Boi("Boizão", 275);

        c1.mostraInfo();
        c1.emitirSom();
        System.out.println(" ");

        l1.mostraInfo();
        l1.emitirSom();
        l1.nadar(l1);
        System.out.println(" ");

        b1.mostraInfo();
        b1.emitirSom();


    }
}
